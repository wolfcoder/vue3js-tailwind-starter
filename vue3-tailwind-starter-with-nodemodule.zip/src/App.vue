<template>
    <router-view/>
</template>

<script lang="js">

export default ({
  name: 'App',
  components: {},
});
</script>

