<template>
  <div class="h-screen w-screen bg-gray-900 text-white">
    <div class="col-auto">
      Home
    </div>
  </div>

</template>

<script>

export default {
  name: 'Home',
}
</script>
